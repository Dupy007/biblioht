@extends('layouts.app')

@section('content')
<component-app></component-app>
@endsection
