<?php $__env->startSection('content'); ?>
<component-app></component-app>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\plf-app\resources\views\home.blade.php ENDPATH**/ ?>